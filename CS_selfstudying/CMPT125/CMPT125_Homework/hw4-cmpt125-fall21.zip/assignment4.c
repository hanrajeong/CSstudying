#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "assignment4.h"

/* Question 1 */

int stack_size(stack_t* s) {
  // implement me
  return -1;
}

bool stack_equal(stack_t* s1, stack_t* s2) {
  // implement me
  return false;
}


char* stack_to_string(stack_t* s) {
  // implement me
  return NULL;
}


char* get_arithmetic_expression(BTnode_t* expression) {
  // implement me
  return NULL;
}


BTnode_t* find(BTnode_t* root, bool (*pred)(int)) {
  // implement me
  return NULL;
}


void map(BTnode_t* root, int (*f)(int)) {
  // implement me
  return;
}


BTnode_t* copy_tree(BTnode_t* root) {
  // implement me
  return NULL;
}



#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "assignment3.h"

int rearrange(int* A, int n, int pivot_index) {
  // implement me
  return 0;
}


void quick_sort(int* A, int n) {
  // implement me
}


void sort_points(point* A, int length) {
  // implement me
}


int find(int* A, int n, bool (*pred)(int)) {
  // implement me
  return -1;
}


void map(int* A, int n, int (*f)(int)) {
  // implement me
}


int reduce(int* A, int n, int (*f)(int,int)) {
  // implement me
  return -1;
}

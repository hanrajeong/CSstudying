#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "sample.h"


bool contains(const int* a1, int len, const int* a2, int len2) {
  // implement me
  return true;
}

 
int last_len(const char* str) {
  // implement me
  return -1;
}


int BT_sum(const BTnode_t* root) {
  // implement me
  return -1;
}
